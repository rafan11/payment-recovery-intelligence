import {Dashboard} from '@/components/dashboard';import {MobileNav} from '@/components/mobile-nav';export default function Page(){return <><Dashboard/><MobileNav/></>}
